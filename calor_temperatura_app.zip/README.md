# Calor y Temperatura

Este proyecto explica la diferencia entre **calor** y **temperatura**, incluye las **fórmulas de conversión** entre escalas de temperatura y algunos **ejercicios de ejemplo**.  

La idea es que pueda usarse como recurso educativo desde **computador** o **celular**.

---

## Conceptos básicos

- **Temperatura**: mide el nivel de agitación de las partículas de un cuerpo.  
- **Calor**: es energía en tránsito, se transfiere de un cuerpo a otro por diferencia de temperatura.  

---

## Fórmulas de conversión de temperatura

- Celsius → Kelvin: `K = °C + 273.15`  
- Kelvin → Celsius: `°C = K - 273.15`  
- Celsius → Fahrenheit: `°F = (°C × 9/5) + 32`  
- Fahrenheit → Celsius: `°C = (°F - 32) × 5/9`  

---

## Ejercicios de ejemplo

1. Convierte 25 °C a Kelvin → 298.15 K  
2. Convierte 0 °C a Fahrenheit → 32 °F  
3. Convierte 100 °F a Celsius → 37.8 °C  
